﻿using UnityEngine;
using System.Collections;

public class StatCollectionClass : MonoBehaviour {


	public int health;
			
		

	public float mana;
			

	public int strength;
			

	public int intellect;
			

	public int xp;
			

	public int playerLevel;

	public bool item1;

	public bool EnergyBallUnlocked;

	public bool FireBreathUnlocked;

	public bool SunStrikeUnlocked;


}

