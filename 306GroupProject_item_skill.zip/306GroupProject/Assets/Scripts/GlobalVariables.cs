﻿using UnityEngine;
using System.Collections;

public static class GlobalVariables  {

	// Kill counter
	public static int kills = 0;

	//Coin counter

	public static int CoinNum = 0;
}
